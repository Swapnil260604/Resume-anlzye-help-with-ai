import { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

const initialResumes = [
  { name: "Resume A", text: "Experienced student with strong programming, data analysis, and communication skills." },
  { name: "Resume B", text: "Recent graduate with internship experience in product design and campus operations." },
];

export default function App() {
  const [jobDescription, setJobDescription] = useState("");
  const [resumes] = useState(initialResumes);
  const [results, setResults] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    document.title = "Resume.Match";
  }, []);

  const handleSubmit = async () => {
    if (!jobDescription.trim()) {
      setError("Enter a job description.");
      return;
    }
    setError("");

    try {
      const response = await axios.post("http://localhost:8000/api/resume/shortlist", {
        job_description: jobDescription,
        resumes,
      });
      setResults(response.data);
    } catch (err) {
      setError(err.response?.data?.detail || "Unable to shortlist resumes.");
    }
  };

  return (
    <main className="main-container">
      <h1 className="page-title">Resume.Match</h1>
      <div className="card" style={{ display: "grid", gap: 24 }}>
        <div className="field-group">
          <label htmlFor="jobDescription">Job description</label>
          <textarea
            id="jobDescription"
            className="textarea"
            value={jobDescription}
            onChange={(e) => setJobDescription(e.target.value)}
            placeholder="Paste the job description here"
          />
        </div>
        <button className="button" onClick={handleSubmit}>Shortlist resumes</button>
        {error && <div style={{ color: "#b91c1c" }}>{error}</div>}
        {results && (
          <div style={{ display: "grid", gap: 18 }}>
            <div>
              <h2>Top keywords</h2>
              <p>{results.top_keywords.join(", ")}</p>
            </div>
            {results.results.map((item) => (
              <div key={item.name} className="card" style={{ padding: 20 }}>
                <h3>{item.name} — {item.score}%</h3>
                <p>{item.snippet}</p>
                <p><strong>Matched:</strong> {item.matched_keywords.join(", ")}</p>
                <p><strong>Missing:</strong> {item.missing_keywords.join(", ")}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
