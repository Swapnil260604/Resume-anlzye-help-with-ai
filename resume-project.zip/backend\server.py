from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
import re
from pathlib import Path
from pydantic import BaseModel
from typing import List, Optional
import uuid
from datetime import datetime, timezone
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI(title="Resume Shortlisting Project")
api_router = APIRouter(prefix="/api")

class ResumeItem(BaseModel):
    name: str
    text: str

class ResumeShortlistRequest(BaseModel):
    job_description: str
    resumes: List[ResumeItem]

class ResumeResult(BaseModel):
    name: str
    score: float
    matched_keywords: List[str]
    missing_keywords: List[str]
    snippet: str

class ResumeShortlistResponse(BaseModel):
    results: List[ResumeResult]
    top_keywords: List[str]

STOPWORDS = set("""
    a about above after again against all am an and any are as at be because been before being below
    between both but by could did do does doing down during each few for from further had has have having
    he her here hers herself him himself his how i if in into is it its itself just me more most my
    myself no nor not now of off on once only or other our ours ourselves out over own same she should
    so some such than that the their theirs them themselves then there these they this those through
    to too under until up very was we were what when where which while who whom why will with would
    you your yours yourself yourselves can may might shall must also etc using used use one two three
""".split())

def tokenize(text: str) -> List[str]:
    text = text.lower()
    tokens = re.findall(r"[a-zA-Z][a-zA-Z+#\.\-]*[a-zA-Z+#]|[a-zA-Z]", text)
    return [t for t in tokens if t not in STOPWORDS and len(t) > 1]


def extract_top_keywords(text: str, k: int = 15) -> List[str]:
    tokens = tokenize(text)
    freq = {}
    for t in tokens:
        freq[t] = freq.get(t, 0) + 1
    return [w for w, _ in sorted(freq.items(), key=lambda x: -x[1])[:k]]

@api_router.post("/resume/shortlist", response_model=ResumeShortlistResponse)
async def resume_shortlist(req: ResumeShortlistRequest):
    if not req.job_description.strip():
        raise HTTPException(status_code=400, detail="Job description required")
    if not req.resumes:
        raise HTTPException(status_code=400, detail="At least one resume required")

    job_kw = extract_top_keywords(req.job_description, 20)
    job_kw_set = set(job_kw)
    corpus = [req.job_description] + [r.text for r in req.resumes]

    try:
        vectorizer = TfidfVectorizer(stop_words='english', ngram_range=(1, 2), max_features=2000, lowercase=True)
        tfidf = vectorizer.fit_transform(corpus)
        sims = cosine_similarity(tfidf[0:1], tfidf[1:]).flatten()
    except ValueError:
        sims = [0.0] * len(req.resumes)

    results = []
    for i, r in enumerate(req.resumes):
        resume_tokens = set(tokenize(r.text))
        matched = sorted(list(job_kw_set & resume_tokens))
        missing = sorted(list(job_kw_set - resume_tokens))
        score = float(sims[i]) * 100.0
        snippet = (r.text[:200] + "...") if len(r.text) > 200 else r.text
        results.append(ResumeResult(
            name=r.name, score=round(score, 2),
            matched_keywords=matched[:15], missing_keywords=missing[:10], snippet=snippet,
        ))

    results.sort(key=lambda x: -x.score)

    await db.resume_runs.insert_one({
        "id": str(uuid.uuid4()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "job_description_preview": req.job_description[:200],
        "num_resumes": len(req.resumes),
        "top_score": results[0].score if results else 0,
    })

    return ResumeShortlistResponse(results=results, top_keywords=job_kw)

app.include_router(api_router)
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
